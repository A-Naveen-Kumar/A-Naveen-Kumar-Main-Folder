﻿using System;
using System.Collections.Generic;

namespace CollegeExamMgm
{
    class Result
    {
        public int AutoId { get; set; }
        public int StudentAutoId { get; set; }
        public string Evaluation { get; set; }
    }
}
