﻿using System.Collections.Generic;

namespace CollegeExamMgm
{
    interface ISemester
    {
        List<Exam> Sem();
    }
}
