﻿using System;
using System.Collections.Generic;

namespace CollegeExamMgm
{
    interface IView
    {
        void ViewOperation(List<Student> request);
    }
}
