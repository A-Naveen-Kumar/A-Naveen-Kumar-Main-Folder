﻿using System;
using System.Collections.Generic;

namespace CollegeExamMgm
{
    interface IAdd
    {
        void AddOperation(Student request);
    }
}
