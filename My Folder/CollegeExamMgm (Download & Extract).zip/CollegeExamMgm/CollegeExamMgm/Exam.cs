﻿using System;
using System.Collections.Generic;

namespace CollegeExamMgm
{
    public class Exam
    {
        public static int AutoId { get; set; }
        public string SubName { get; set; }
        public int SubMarks { get; set; }

        //public static Dictionary<string, int> Semester = new Dictionary<string, int>();
        //public string Semester { get; set; }
        //public string Evaluation { get; set; }
        //public int StudentAutoId { get; set; }
    }
}
