﻿using System;
using System.Collections.Generic;

namespace CollegeExamMgm
{
    interface IUpdate
    {
        void UpdateOperation(Student request);
    }
}
