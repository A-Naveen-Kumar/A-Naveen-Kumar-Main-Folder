﻿using System;
using System.Collections.Generic;

namespace CollegeExamMgm
{
    public class Student
    {
        public int AutoId { get; set; }
        public int StudentRegNo { get; set; }
        public string StudentName { get; set; }
        public string DOB { get; set; }
        public string BloodGroup { get; set; }
        public string City { get; set; }
        public string Department { get; set; }


        //public List<Student> StudentList { get; set; }
        //public List<Result> Result { get; set; }
    }
}
