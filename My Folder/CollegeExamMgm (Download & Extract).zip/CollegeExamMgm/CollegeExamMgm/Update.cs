﻿using System;
using System.Collections.Generic;

namespace CollegeExamMgm
{
    class Update : IUpdate
    {
        public void UpdateOperation(Student request)
        {
            UpdateStudent();
            UpdateExamDtl();
        }

        private void UpdateStudent()
        {

        }

        private void UpdateExamDtl()
        {

        }
    }
}
